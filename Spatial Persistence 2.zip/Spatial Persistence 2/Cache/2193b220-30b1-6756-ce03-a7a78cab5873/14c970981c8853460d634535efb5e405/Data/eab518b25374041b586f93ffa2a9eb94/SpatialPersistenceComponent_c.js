if (script.onAwake) {
	script.onAwake();
	return;
};
function checkUndefined(property, showIfData){
   for (var i = 0; i < showIfData.length; i++){
       if (showIfData[i][0] && script[showIfData[i][0]] != showIfData[i][1]){
           return;
       }
   }
   if (script[property] == undefined){
      throw new Error('Input ' + property + ' was not provided for the object ' + script.getSceneObject().name);
   }
}
// @input Asset.LocationCloudStorageModule locationCloudStorageModule
// @input Asset.ConnectedLensModule connectedLensModule
// @input bool useLocalStorage
// @input float mappingInterval = 20
// @input float resetDelayInS = 0.5
// @input bool debug = true
// @input bool incrementalMapping
// @input bool enableLoggingPoseSettling
var scriptPrototype = Object.getPrototypeOf(script);
if (!global.BaseScriptComponent){
   function BaseScriptComponent(){}
   global.BaseScriptComponent = BaseScriptComponent;
   global.BaseScriptComponent.prototype = scriptPrototype;
   global.BaseScriptComponent.prototype.__initialize = function(){};
   global.BaseScriptComponent.getTypeName = function(){
       throw new Error("Cannot get type name from the class, not decorated with @component");
   }
}
var Module = require("../../../../../Modules/Src/Packages/SpatialAnchors.lspkg/SpatialPersistence/SpatialPersistenceComponent");
Object.setPrototypeOf(script, Module.SpatialPersistenceComponent.prototype);
script.__initialize();
let awakeEvent = script.createEvent("OnAwakeEvent");
awakeEvent.bind(() => {
    checkUndefined("locationCloudStorageModule", []);
    checkUndefined("connectedLensModule", []);
    checkUndefined("useLocalStorage", []);
    checkUndefined("mappingInterval", []);
    checkUndefined("resetDelayInS", []);
    checkUndefined("debug", []);
    checkUndefined("incrementalMapping", []);
    checkUndefined("enableLoggingPoseSettling", []);
    if (script.onAwake) {
       script.onAwake();
    }
});
