"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PinchEventType = void 0;
var PinchEventType;
(function (PinchEventType) {
    PinchEventType["Down"] = "Down";
    PinchEventType["Up"] = "Up";
    PinchEventType["Cancel"] = "Cancel";
})(PinchEventType || (exports.PinchEventType = PinchEventType = {}));
//# sourceMappingURL=PinchEventType.js.map